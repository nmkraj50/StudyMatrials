﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace BinarySerializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(){ ID = 101, Name = "Robert", City = "Mumbai", Salary = 30000 };
            FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(fs, emp);
            fs.Close();
            Console.WriteLine("Serialization Done");

            fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
            Employee deserializedEmp = (Employee)bin.Deserialize(fs);
            fs.Close();
            Console.WriteLine("Employee ID : " + deserializedEmp.ID);
            Console.WriteLine("Employee Name : " + deserializedEmp.Name);
            Console.WriteLine("Salary : " + deserializedEmp.Salary);
            Console.WriteLine("City : " + deserializedEmp.City);

            Console.ReadKey();
        }
    }
}
