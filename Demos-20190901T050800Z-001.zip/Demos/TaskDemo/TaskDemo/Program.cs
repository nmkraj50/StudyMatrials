﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace TaskDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Program p = new Program();

            //Stopwatch sw = Stopwatch.StartNew();
            //p.BookFlight();
            //p.BookHotel();
            //p.BookTaxi();
            //sw.Stop();
            //long seqTime = sw.ElapsedMilliseconds;

            //Console.WriteLine();

            //sw = Stopwatch.StartNew();
            //Task flightTask = Task.Factory.StartNew(() => p.BookFlight());
            //Task hotelTask = Task.Factory.StartNew(() => p.BookHotel());
            //Task taxiTask = Task.Factory.StartNew(() => p.BookTaxi());

            //Task.WaitAll(flightTask, hotelTask, taxiTask);

            //sw.Stop();
            //long parTime = sw.ElapsedMilliseconds;

            //Console.WriteLine("\nTime taken by sequential execution : " + seqTime);
            //Console.WriteLine("Time taken by parallel execution : " + parTime);

            try
            {
                int? number = null;

                if (number == null)
                {
                    throw new Exception(nameof(number) + " is null");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }


            Console.ReadKey();
        }

        public void BookFlight()
        {
            Console.WriteLine("Flight Booking Started...");
            System.Threading.Thread.Sleep(5000);
            Console.WriteLine("Flight Booking Completed");
        }

        public void BookHotel()
        {
            Console.WriteLine("Hotel Booking Started...");
            System.Threading.Thread.Sleep(8000);
            Console.WriteLine("Hotel Booking Completed");
        }

        public void BookTaxi()
        {
            Console.WriteLine("Taxi Booking Started...");
            System.Threading.Thread.Sleep(3000);
            Console.WriteLine("Taxi Booking Completed");
        }
    }
}
