﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoVariance3Demo
{
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public Employee(int id, string name)
        {
            ID = id;
            Name = name;
        }
    }

    public class Manager : Employee
    {
        public int Incentives { get; set; }

        public Manager(int id, string name, int inc) : base(id, name)
        {
            Incentives = inc;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();

            empList.Add(new Employee(101, "Robert"));
            empList.Add(new Employee(102, "Tennyson"));
            empList.Add(new Employee(103, "Maria"));

            Console.WriteLine("Employee Details : ");
            IEnumerable<Employee> empIterate = empList;
            foreach (Employee emp in empIterate)
            {
                Console.WriteLine(emp.ID + "\t" + emp.Name);
            }

            List<Manager> mgrlist = new List<Manager>();
            mgrlist.Add(new Manager(201, "Allister", 2334));
            mgrlist.Add(new Manager(202, "Sofia", 2334));
            mgrlist.Add(new Manager(203, "Roseline", 2334));
            mgrlist.Add(new Manager(204, "Walton", 2334));
            mgrlist.Add(new Manager(205, "Albert", 2334));

            empIterate = mgrlist;

            Console.WriteLine("\n\nManager Details : ");
            foreach (var item in empIterate)
            {
                Console.WriteLine(item.ID + "\t" + item.Name);
            }

            Console.ReadKey();
        }
    }
}
