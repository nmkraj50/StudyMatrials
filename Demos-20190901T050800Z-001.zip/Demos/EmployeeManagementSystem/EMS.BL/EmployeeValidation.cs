﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;

namespace EMS.BL
{
    public class EmployeeValidation
    {
        public static bool ValidateEmployee(Employee emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (emp.ID < 100000 || emp.ID > 999999)
                {
                    empValidated = false;
                    message.Append("Employee ID should be 6 digits long\n");
                }

                if (string.IsNullOrEmpty(emp.Name))
                {
                    empValidated = false;
                    message.Append("Employee Name should be provided\n");
                }
                else if (!Regex.IsMatch(emp.Name, "[A-Z][a-z]+"))
                {
                    empValidated = false;
                    message.Append("Employee Name should start with capital alphabet and it should have alphabets only\n");
                }

                if (emp.DOJ > DateTime.Now)
                {
                    empValidated = false;
                    message.Append("Date of Joining should be less than or equal to current date");
                }

                if (empValidated == false)
                {
                    throw new EmployeeException(message.ToString());
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        public static bool AddEmployee(Employee emp)
        {
            bool empAdded = true;

            try
            {
                if (ValidateEmployee(emp))
                {
                    empAdded = EmployeeOperations.AddEmployee(emp);
                }
                else
                    throw new EmployeeException("Please provide valida employee details");
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }

        public static bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;

            try
            {
                if (ValidateEmployee(emp))
                {
                    empUpdated = EmployeeOperations.UpdateEmployee(emp);
                }
                else
                    throw new EmployeeException("Please provide valid employee details for update");
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        public static bool DeleteEmployee(int id)
        {
            bool empDeleted = false;

            try
            {
                empDeleted = EmployeeOperations.DeleteEmployee(id);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDeleted;
        }

        public static Employee SearchEmployee(int id)
        {
            Employee emp = null;

            try
            {
                emp = EmployeeOperations.SearchEmployee(id);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        public static List<Employee> RetrieveEmployees()
        {
            List<Employee> empList = null;

            try
            {
                empList = EmployeeOperations.RetrieveEmployees();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }

        public static bool SerializeEmployee()
        {
            bool empSerialized = false;

            try
            {
                empSerialized = EmployeeOperations.SerializeEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        public static List<Employee> DeserializeEmployee()
        {
            List<Employee> empList = null;

            try
            {
                empList = EmployeeOperations.DeserializeEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }
    }
}
