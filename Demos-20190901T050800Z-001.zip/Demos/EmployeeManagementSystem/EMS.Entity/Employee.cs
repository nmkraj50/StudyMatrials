﻿using System;

namespace EMS.Entity
{
    [Serializable]
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public DateTime DOJ { get; set; }
        public double Salary { get; set; }
    }
}
