﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using EMS.Entity;
using EMS.Exception;


namespace EMS.DAL
{
    public class EmployeeOperations
    {
        static List<Employee> empList = new List<Employee>();

        public static bool AddEmployee(Employee emp)
        {
            bool empAdded = false;

            try
            {
                empList.Add(emp);
                empAdded = true;
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }

        public static bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;

            try
            {
                for (int i = 0; i < empList.Count; i++)
                {
                    if (empList[i].ID == emp.ID)
                    {
                        empList[i].Name = emp.Name;
                        empList[i].DOJ = emp.DOJ;
                        empList[i].Salary = emp.Salary;
                        empUpdated = true;
                    }
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        public static bool DeleteEmployee(int id)
        {
            bool empDeleted = false;

            try
            {
                Employee emp = empList.Find(e => e.ID == id);

                if (emp != null)
                {
                    empList.Remove(emp);
                    empDeleted = true;
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDeleted;
        }

        public static Employee SearchEmployee(int id)
        {
            Employee emp = null;

            try
            {
                emp = empList.Find(e => e.ID == id);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        public static List<Employee> RetrieveEmployees()
        {
            return empList;
        }

        public static bool SerializeEmployee()
        {
            bool empSerialized = false;

            try
            {
                FileStream fs = new FileStream("Emp.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, empList);
                fs.Close();
                empSerialized = true;
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        public static List<Employee> DeserializeEmployee()
        {
            List<Employee> desEmpList = null;

            try
            {
                FileStream fs = new FileStream("Emp.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desEmpList = bin.Deserialize(fs) as List<Employee>;
                fs.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desEmpList;
        }
    }
}
