﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace XMLSerializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee() { ID = 101, Name = "Robert", City = "Mumbai", Salary=30000 };
            FileStream fs = new FileStream("Employee.xml", FileMode.Create, FileAccess.Write);
            XmlSerializer ser = new XmlSerializer(typeof(Employee));
            ser.Serialize(fs, emp);
            fs.Close();
            Console.WriteLine("Object Serialized");

            fs = new FileStream("Employee.xml", FileMode.Open, FileAccess.Read);
            Employee deserializedEmp = (Employee)ser.Deserialize(fs);
            fs.Close();

            Console.WriteLine("Employee ID : " + deserializedEmp.ID);
            Console.WriteLine("Employee Name : " + deserializedEmp.Name);
            Console.WriteLine("Salary : " + deserializedEmp.Salary);
            Console.WriteLine("City : " + deserializedEmp.City);

            Console.ReadKey();
        }
    }
}
