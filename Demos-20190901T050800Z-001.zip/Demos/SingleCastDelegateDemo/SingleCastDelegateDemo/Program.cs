﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleCastDelegateDemo
{
    public delegate double MyDelegate(double val);

    public delegate int CalculateDelegate(int num1, int num2);

    class Program
    {
        public int Addition(int num1, int num2)
        {
            return num1 + num2;
        }

        static void Main(string[] args)
        {
            MyDelegate delObj = new MyDelegate(Math.Sin);

            //double sinResult = delObj(1.0);

            double sinResult = delObj.Invoke(1.0);

            Console.WriteLine($"Sin(1.0) is => {sinResult}");

            Program p = new Program();

            //CalculateDelegate calDel = new CalculateDelegate(p.Addition);
            CalculateDelegate calDel = p.Addition;

            int addresult = calDel(10, 20);

            Console.WriteLine($"10 + 20 => {addresult}");


            Console.ReadKey();
        }
    }
}
