﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegateDemo
{
    public delegate void CalculateDelegate(int val1, int val2);
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();

            CalculateDelegate calDel = new CalculateDelegate(cal.Addition);
            calDel += new CalculateDelegate(Calculate.Subtract);
            calDel += new CalculateDelegate(cal.Addition);
            calDel += cal.Divide;
            calDel += Calculate.Multiply;

            calDel(20, 10);

            //Console.WriteLine("Result is : " + result);

            calDel -= cal.Addition;

            Console.WriteLine();
            calDel(30, 5);

            Delegate[] delList = calDel.GetInvocationList();
            Console.WriteLine("\nDelegate Invocation List : ");
            foreach (var item in delList)
            {
                Console.WriteLine(item.Method);
            }

            Console.ReadKey();
        }
    }
}
