﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredicateDelegateDemo
{
    class Program
    {
        public bool IsEven(int num)
        {
            if (num % 2 == 0)
                return true;

            return false;
        }
        static void Main(string[] args)
        {
            Predicate<string> strDel = string.IsNullOrEmpty;
            Console.WriteLine("String is null or empty : " + strDel(""));
            Console.WriteLine("String is null or empty : " + strDel(null));
            Console.WriteLine("String is null or empty : " + strDel(".NET"));

            Program p = new Program();
            Predicate<int> evenDel = p.IsEven;
            Console.WriteLine("Is Even : " + evenDel(56));
            Console.WriteLine("Is Even : " + evenDel(231));

            Console.ReadKey();
        }
    }
}
