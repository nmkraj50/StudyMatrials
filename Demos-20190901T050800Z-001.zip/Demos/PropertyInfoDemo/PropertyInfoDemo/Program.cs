﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace PropertyInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type emp = myAssembly.GetType("ReflectionLibrary.Employee");

            PropertyInfo[] props = emp.GetProperties();

            Console.WriteLine("Number of Properties : " + props.Length);

            foreach (PropertyInfo p in props)
            {
                Console.WriteLine("Property Name : " + p.Name);
                Console.WriteLine("Can Read : " + p.CanRead);
                Console.WriteLine("Can Write : " + p.CanWrite);
                Console.WriteLine("Declaring Type : " + p.DeclaringType);
                Console.WriteLine("Property Type : " + p.PropertyType);
                Console.WriteLine("*****************************************************\n");
            }

            object obj = myAssembly.CreateInstance("ReflectionLibrary.Employee");

            PropertyInfo idProp = emp.GetProperty("EmpID");
            idProp.SetValue(obj, 101);
            Console.WriteLine("Employee ID : " + idProp.GetValue(obj));

            Console.ReadKey();
        }
    }
}
