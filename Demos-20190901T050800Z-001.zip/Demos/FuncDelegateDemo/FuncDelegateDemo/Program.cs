﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncDelegateDemo
{
    class Program
    {
        //public void Show()
        //{
        //    Console.WriteLine("Show method called");
        //}

        public string Show()
        {
            return "Show method called";
        }

        public int CountDigit(string str)
        {
            int count = 0;

            for (int i = 0; i < str.Length; i++)
            {
                if (Char.IsDigit(str[i]))
                    count++;
            }

            return count;
        }

        static void Main(string[] args)
        {
            //Func<void> Error : void is not valid return type
            Program p = new Program();
            Func<string> del1 = p.Show;
            Console.WriteLine(del1());

            Func<string, int> countDel = p.CountDigit;
            Console.WriteLine("Number of Digits : " + countDel("XY12PQ3A1CRD"));

            Func<int, int, int> addDel = delegate (int num1, int num2) { return num1 + num2; };
            Console.WriteLine("Addition is : " + addDel(10, 30));

            Func<int, int, int> multDel = (num1, num2) => num1 * num2;
            Console.WriteLine("Multiplication is : " + multDel(10, 5));

            Console.ReadKey();
        }
    }
}
