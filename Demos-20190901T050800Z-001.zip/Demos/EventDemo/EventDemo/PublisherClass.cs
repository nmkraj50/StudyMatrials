﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    public delegate void EventDelegate(string message);

    public class PublisherClass
    {
        public event EventDelegate MyEvent;

        public void NotifySubscriber(string message)
        {
            if (MyEvent != null)
            {
                Console.WriteLine("Notifying Subscriber");
                MyEvent(message);
            }
            else
            {
                Console.WriteLine("No Subscriber Available");
            }
        }
    }
}
