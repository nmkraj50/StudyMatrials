﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace IDeserializationCallbackDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product(101, "Pen", 15, 10);
            FileStream fs = new FileStream("Product.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(fs, p);
            fs.Close();
            Console.WriteLine("Object Serialized");

            fs = new FileStream("Product.txt", FileMode.Open, FileAccess.Read);
            Product desProd = bin.Deserialize(fs) as Product;
            fs.Close();
            //desProd.CalculateTotal();
            Console.WriteLine("Product ID : " + desProd.ProdID);
            Console.WriteLine("Product Name : " + desProd.ProdName);
            Console.WriteLine("Quantity : " + desProd.Quantity);
            Console.WriteLine("Unit Price : " + desProd.Price);
            Console.WriteLine("Total Price : " + desProd.TotalPrice);

            Console.ReadKey();
        }
    }
}
